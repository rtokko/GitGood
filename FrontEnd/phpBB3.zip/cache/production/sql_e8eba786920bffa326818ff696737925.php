<?php exit; ?>
1553888375
SELECT notification_type_id, notification_type_name FROM phpbb_1notification_types
665
a:6:{i:0;a:2:{s:20:"notification_type_id";s:1:"6";s:22:"notification_type_name";s:30:"notification.type.approve_post";}i:1;a:2:{s:20:"notification_type_id";s:1:"2";s:22:"notification_type_name";s:31:"notification.type.approve_topic";}i:2;a:2:{s:20:"notification_type_id";s:1:"4";s:22:"notification_type_name";s:26:"notification.type.bookmark";}i:3;a:2:{s:20:"notification_type_id";s:1:"5";s:22:"notification_type_name";s:22:"notification.type.post";}i:4;a:2:{s:20:"notification_type_id";s:1:"3";s:22:"notification_type_name";s:23:"notification.type.quote";}i:5;a:2:{s:20:"notification_type_id";s:1:"1";s:22:"notification_type_name";s:23:"notification.type.topic";}}