<?php exit; ?>
1553647378
SELECT m.*, u.user_colour, g.group_colour, g.group_type FROM (phpbb_1moderator_cache m) LEFT JOIN phpbb_1users u ON (m.user_id = u.user_id) LEFT JOIN phpbb_1groups g ON (m.group_id = g.group_id) WHERE m.display_on_index = 1
6
a:0:{}