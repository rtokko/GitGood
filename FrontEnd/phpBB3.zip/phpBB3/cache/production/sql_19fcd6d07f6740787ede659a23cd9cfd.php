<?php exit; ?>
1557958954
SELECT forum_id FROM phpbb_1forums WHERE forum_options & 2 <> 0 LIMIT 1
6
a:0:{}