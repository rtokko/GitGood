<?php exit; ?>
1557958960
SELECT forum_id, forum_name, parent_id, forum_type, left_id, right_id FROM phpbb_1forums ORDER BY left_id ASC
509
a:3:{i:0;a:6:{s:8:"forum_id";s:1:"1";s:10:"forum_name";s:19:"Your first category";s:9:"parent_id";s:1:"0";s:10:"forum_type";s:1:"0";s:7:"left_id";s:1:"1";s:8:"right_id";s:1:"6";}i:1;a:6:{s:8:"forum_id";s:1:"2";s:10:"forum_name";s:16:"Your first forum";s:9:"parent_id";s:1:"1";s:10:"forum_type";s:1:"1";s:7:"left_id";s:1:"2";s:8:"right_id";s:1:"5";}i:2;a:6:{s:8:"forum_id";s:1:"3";s:10:"forum_name";s:7:"GitGood";s:9:"parent_id";s:1:"2";s:10:"forum_type";s:1:"1";s:7:"left_id";s:1:"3";s:8:"right_id";s:1:"4";}}